# LSH过程证明三步

**User:** Anonymous  

## Prompt:
我现在要写“技术是如何实现的”的部分，请你总结一下论文中证明LSH的过程，分三步：限制哈希桶大小、用随机游走连接近点碰撞、用小集合扩散性质给出上界

## Response:
下面这段可直接作为“技术是如何实现的”部分。

**document: **

## 技术实现：LSH 下界证明的三步框架

论文并不是构造一种新的 LSH，而是证明：在高维 Hamming 立方体上，任何满足局部敏感条件的哈希族，其近点碰撞概率 $p$ 和远点碰撞概率 $q$ 都不能任意分离。证明的核心是把每个哈希桶看成 Hamming 立方体中的一个集合，再利用随机游走和小集合扩散性质限制随机游走留在同一哈希桶中的概率。

### 第一步：利用远点碰撞条件限制哈希桶大小

固定一个点 $x\in\{0,1\}^d$，考虑包含 $x$ 的哈希桶

$$
B_x=H^{-1}(H(x)).
$$

桶的大小可以写成

$$
|B_x|
=
\sum_{u\in\{0,1\}^d}
\mathbf{1}[H(u)=H(x)].
$$

对随机哈希函数 $H$ 取期望，有

$$
\mathbb{E}_H|B_x|
=
\sum_{u\in\{0,1\}^d}
\Pr_H[H(u)=H(x)].
$$

按照 $u$ 与 $x$ 的 Hamming 距离，将所有点分成两类。

当

$$
\|u-x\|_1\le R
$$

时，论文不对碰撞概率作有效的上界，因此直接用 $1$ 估计；当

$$
\|u-x\|_1>R
$$

时，根据 LSH 的远点条件，碰撞概率至多为 $q$。因此

$$
\mathbb{E}_H|B_x|
\le
\sum_{k=0}^{\lfloor R\rfloor}\binom{d}{k}
+
q\sum_{k=\lfloor R\rfloor+1}^{d}\binom{d}{k}.
$$

当 $R<d/2$ 时，Hamming 球的体积可以通过二项分布的尾界估计：

$$
\sum_{k=0}^{\lfloor R\rfloor}\binom{d}{k}
\le
2^d
\exp\left(
-\frac{(d/2-R)^2}{d}
\right).
$$

于是得到

$$
\frac{\mathbb{E}_H|B_x|}{2^d}
\le
q+
\exp\left(
-\frac{(d/2-R)^2}{d}
\right).
$$

这说明，一个随机点所在哈希桶占整个 Hamming 立方体的比例，在期望意义下不会明显超过 $q$。直观上，如果某个桶过大，其中就会包含大量距离超过 $R$ 的点，从而导致远点碰撞概率超过 $q$。

### 第二步：用随机游走表示近点碰撞

从均匀随机点 $x\in\{0,1\}^d$ 出发，在 Hamming 立方体上进行 $r$ 步标准随机游走。每一步随机选择一个坐标并将其翻转，记最终位置为

$$
W_r(x).
$$

由于每一步至多改变一个坐标，因此

$$
\|x-W_r(x)\|_1\le r.
$$

根据 LSH 的近点条件，

$$
\Pr_H[H(W_r(x))=H(x)]\ge p.
$$

对随机起点 $x$ 和随机哈希函数 $H$ 取平均，可得

$$
p
\le
\mathbb{E}_{H,x}
\mathbf{1}[H(W_r(x))=H(x)].
$$

对于固定的哈希函数 $H$，设它产生的哈希桶为

$$
B_k=H^{-1}(k).
$$

事件

$$
H(W_r(x))=H(x)
$$

等价于随机游走的起点和终点落在同一个桶中。因此，上式可以按哈希桶分解为

$$
p
\le
\mathbb{E}_H
\sum_k
\frac{|B_k|}{2^d}
\Pr[Q_{B_k}\in B_k],
$$

其中 $Q_B$ 表示：先从集合 $B$ 中均匀选择一个起点，再进行 $r$ 步随机游走后得到的终点。

因此，近点必须以至少 $p$ 的概率碰撞，意味着随机游走必须以至少 $p$ 的平均概率留在原来的哈希桶中。证明由此转化为一个几何问题：一个较小的集合能在多大程度上留住随机游走？

### 第三步：利用小集合扩散性质给出留存概率上界

论文证明了如下随机游走引理。对于任意非空集合

$$
B\subseteq\{0,1\}^d,
$$

当 $r$ 为奇数时，

$$
\Pr[Q_B\in B]
\le
\left(
\frac{|B|}{2^d}
\right)^\alpha,
$$

其中

$$
\alpha
=
\frac{e^{2r/d}-1}{e^{2r/d}+1}
=
\frac{1-e^{-2r/d}}{1+e^{-2r/d}}.
$$

这个不等式表达了 Hamming 立方体的小集合扩散性质：集合 $B$ 越小，从 $B$ 出发的随机游走就越容易离开 $B$。

该结论通过 Hamming 立方体上的 Fourier 分析得到。随机游走转移矩阵 $P$ 的特征函数是 Walsh 函数 $W_S$，对应特征值为

$$
1-\frac{2|S|}{d}.
$$

因此，随机游走 $r$ 步后仍处于 $B$ 中的概率可以写成

$$
\Pr[Q_B\in B]
=
\frac{2^d}{|B|}
\sum_{S\subseteq[d]}
\widehat{\mathbf{1}_B}(S)^2
\left(
1-\frac{2|S|}{d}
\right)^r.
$$

当 $r$ 为奇数时，满足 $|S|>d/2$ 的项为负数，可以直接删除这些负项以获得上界。随后使用

$$
\left(1-\frac{2|S|}{d}\right)^r
\le
e^{-2r|S|/d}
$$

以及 Bonami-Beckner 不等式，即可将 Fourier 系数之和控制为集合密度 $|B|/2^d$ 的幂，从而得到上述小集合扩散界。

将这一结论代入第二步，有

$$
p
\le
\mathbb{E}_H
\sum_k
\frac{|B_k|}{2^d}
\left(
\frac{|B_k|}{2^d}
\right)^\alpha.
$$

注意到，若 $x$ 在立方体中均匀分布，那么 $x$ 落入桶 $B_k$ 的概率为 $|B_k|/2^d$，因此上式可以重写为

$$
p
\le
\mathbb{E}_{H,x}
\left(
\frac{|H^{-1}(H(x))|}{2^d}
\right)^\alpha.
$$

由于 $0<\alpha<1$，函数 $t^\alpha$ 是凹函数。利用 Jensen 不等式，

$$
p
\le
\left(
\mathbb{E}_{H,x}
\frac{|H^{-1}(H(x))|}{2^d}
\right)^\alpha.
$$

再代入第一步对哈希桶期望大小的估计，得到

$$
p
\le
\left(
q+
\exp\left(
-\frac{(d/2-R)^2}{d}
\right)
\right)^{
\frac{e^{2r/d}-1}{e^{2r/d}+1}
}.
$$

这就是论文 Proposition 2.1 的主要结论。`Lower Bounds on Locality Sensitive Hashing.pdf`

最后，论文选择

$$
R\approx \frac d2-\sqrt{d\log d},
\qquad
r\approx \frac Rc.
$$

此时

$$
\exp\left(
-\frac{(d/2-R)^2}{d}
\right)
\approx \frac1d\to 0,
$$

并且

$$
\frac{2r}{d}\to\frac1c.
$$

因此，当 $d\to\infty$ 时，

$$
p
\lesssim
q^{
\frac{e^{1/c}-1}{e^{1/c}+1}
}.
$$

对两边取对数，得到

$$
\frac{\log(1/p)}{\log(1/q)}
\ge
\frac{e^{1/c}-1}{e^{1/c}+1}.
$$

也就是说，

$$
\rho_1(c)
\ge
\frac{e^{1/c}-1}{e^{1/c}+1}
\sim
\frac1{2c}.
$$

对于一般的 $\ell_s$ 空间，由于在 $\{0,1\}^d$ 上有

$$
\|x-y\|_s
=
\|x-y\|_1^{1/s},
$$

$\ell_s$ 中的距离放大因子 $c$ 对应于 Hamming 距离中的放大因子 $c^s$。因此最终得到

$$
\rho_s(c)
\ge
\frac{e^{1/c^s}-1}{e^{1/c^s}+1}
\ge
\frac{0.462}{c^s}.
$$

整个证明可以概括为：

$$
\text{远点碰撞限制桶大小}
\Longrightarrow
\text{近点碰撞转化为随机游走留存}
\Longrightarrow
\text{小集合扩散限制留存概率}
\Longrightarrow
\text{得到 }p\text{ 与 }q\text{ 的约束及 }\rho\text{ 的下界}.
$$

其中“证明 LSH”更准确的表述是“证明 LSH 参数 $\rho$ 的下界”。

## Prompt:
不需要给我markdown代码块，直接渲染给我

## Response:
## 技术是如何实现的：LSH 下界证明的三步框架

论文并不是构造新的 LSH，而是证明：在高维 Hamming 立方体上，任何满足局部敏感条件的哈希族，其近点碰撞概率 $p$ 和远点碰撞概率 $q$ 都不能任意分离。核心思路是把每个哈希桶视为 Hamming 立方体中的一个集合，再利用随机游走和小集合扩散性质，限制随机游走留在同一哈希桶中的概率。

### 第一步：限制哈希桶大小

固定一个点 $x\in\{0,1\}^d$，考虑包含 $x$ 的哈希桶

$$
B_x=H^{-1}(H(x)).
$$

桶的大小可以写成

$$
|B_x|
=
\sum_{u\in\{0,1\}^d}
\mathbf 1[H(u)=H(x)].
$$

对随机哈希函数 $H$ 取期望：

$$
\mathbb E_H|B_x|
=
\sum_{u\in\{0,1\}^d}
\Pr_H[H(u)=H(x)].
$$

按照 $u$ 与 $x$ 的 Hamming 距离，将所有点分成两类。

当

$$
\|u-x\|_1\le R
$$

时，碰撞概率最多只能粗略地用 $1$ 估计；当

$$
\|u-x\|_1>R
$$

时，根据 LSH 的远点条件，碰撞概率至多为 $q$。因此

$$
\mathbb E_H|B_x|
\le
\sum_{k=0}^{\lfloor R\rfloor}\binom dk
+
q\sum_{k=\lfloor R\rfloor+1}^{d}\binom dk.
$$

当 $R<d/2$ 时，利用二项分布的尾界，可以得到

$$
\sum_{k=0}^{\lfloor R\rfloor}\binom dk
\le
2^d
\exp\left(
-\frac{(d/2-R)^2}{d}
\right).
$$

于是

$$
\frac{\mathbb E_H|B_x|}{2^d}
\le
q+
\exp\left(
-\frac{(d/2-R)^2}{d}
\right).
$$

这说明，一个随机点所在哈希桶占整个 Hamming 立方体的比例，在期望意义下不会明显超过 $q$。

直观上，如果哈希桶太大，其中就会包含大量与 $x$ 距离大于 $R$ 的点，从而导致远点之间的碰撞概率超过 $q$。

---

### 第二步：用随机游走连接近点碰撞

从均匀随机点 $x\in\{0,1\}^d$ 出发，在 Hamming 立方体上进行 $r$ 步标准随机游走。每一步随机选择一个坐标并翻转，记最终位置为

$$
W_r(x).
$$

由于每一步最多改变一个坐标，因此

$$
\|x-W_r(x)\|_1\le r.
$$

根据 LSH 的近点条件，只要两点距离不超过 $r$，它们的碰撞概率至少为 $p$，所以

$$
\Pr_H[H(W_r(x))=H(x)]\ge p.
$$

对随机起点 $x$ 和随机哈希函数 $H$ 取平均：

$$
p
\le
\mathbb E_{H,x}
\mathbf 1[H(W_r(x))=H(x)].
$$

对于固定的哈希函数 $H$，设它产生的哈希桶为

$$
B_k=H^{-1}(k).
$$

事件

$$
H(W_r(x))=H(x)
$$

等价于随机游走的起点和终点位于同一个哈希桶中。因此可以按哈希桶分解：

$$
p
\le
\mathbb E_H
\sum_k
\frac{|B_k|}{2^d}
\Pr[Q_{B_k}\in B_k],
$$

其中 $Q_B$ 表示：先从集合 $B$ 中均匀选择一个起点，再进行 $r$ 步随机游走后得到的终点。

这样，LSH 的近点碰撞条件就被转化为一个随机游走问题：

> 从一个哈希桶中出发，经过 $r$ 步随机游走后，仍然留在该桶中的概率有多大？

如果近点碰撞概率至少为 $p$，那么随机游走平均来说也必须以至少 $p$ 的概率留在原来的哈希桶中。

---

### 第三步：利用小集合扩散性质给出上界

论文证明了如下随机游走引理。对于任意非空集合

$$
B\subseteq\{0,1\}^d,
$$

当 $r$ 为奇数时，

$$
\Pr[Q_B\in B]
\le
\left(
\frac{|B|}{2^d}
\right)^\alpha,
$$

其中

$$
\alpha
=
\frac{e^{2r/d}-1}{e^{2r/d}+1}
=
\frac{1-e^{-2r/d}}{1+e^{-2r/d}}.
$$

这个不等式刻画了 Hamming 立方体中的小集合扩散性质：

$$
|B|\text{ 越小}
\quad\Longrightarrow\quad
\Pr[Q_B\in B]\text{ 越小}.
$$

也就是说，从一个较小的集合出发，随机游走很容易扩散到集合外部。

该结论通过 Hamming 立方体上的 Fourier 分析证明。随机游走转移矩阵 $P$ 的特征函数是 Walsh 函数 $W_S$，对应特征值为

$$
1-\frac{2|S|}{d}.
$$

因此，随机游走 $r$ 步后仍处于 $B$ 中的概率可以写成

$$
\Pr[Q_B\in B]
=
\frac{2^d}{|B|}
\sum_{S\subseteq[d]}
\widehat{\mathbf 1_B}(S)^2
\left(
1-\frac{2|S|}{d}
\right)^r.
$$

当 $r$ 为奇数时，满足 $|S|>d/2$ 的项为负数。为了得到上界，可以删除这些负项。随后使用

$$
\left(
1-\frac{2|S|}{d}
\right)^r
\le
e^{-2r|S|/d}
$$

以及 Bonami-Beckner 不等式，最终得到

$$
\Pr[Q_B\in B]
\le
\left(
\frac{|B|}{2^d}
\right)^\alpha.
$$

将该结论代入第二步：

$$
p
\le
\mathbb E_H
\sum_k
\frac{|B_k|}{2^d}
\left(
\frac{|B_k|}{2^d}
\right)^\alpha.
$$

由于随机点 $x$ 落入桶 $B_k$ 的概率为 $|B_k|/2^d$，上式可写为

$$
p
\le
\mathbb E_{H,x}
\left(
\frac{|H^{-1}(H(x))|}{2^d}
\right)^\alpha.
$$

因为 $0<\alpha<1$，函数 $t^\alpha$ 是凹函数。利用 Jensen 不等式：

$$
p
\le
\left(
\mathbb E_{H,x}
\frac{|H^{-1}(H(x))|}{2^d}
\right)^\alpha.
$$

再代入第一步得到的哈希桶大小上界：

$$
p
\le
\left(
q+
\exp\left(
-\frac{(d/2-R)^2}{d}
\right)
\right)^{
\frac{e^{2r/d}-1}{e^{2r/d}+1}
}.
$$

这就是论文 Proposition 2.1 的核心结论。`Lower Bounds on Locality Sensitive Hashing.pdf`

---

### 最终得到 LSH 参数的下界

论文选择

$$
R\approx \frac d2-\sqrt{d\log d},
\qquad
r\approx \frac Rc.
$$

此时

$$
\exp\left(
-\frac{(d/2-R)^2}{d}
\right)
\approx
\frac1d
\to 0,
$$

并且

$$
\frac{2r}{d}\to\frac1c.
$$

因此，当 $d\to\infty$ 时，

$$
p
\lesssim
q^{
\frac{e^{1/c}-1}{e^{1/c}+1}
}.
$$

对两边取对数，得到

$$
\frac{\log(1/p)}{\log(1/q)}
\ge
\frac{e^{1/c}-1}{e^{1/c}+1}.
$$

即

$$
\rho_1(c)
\ge
\frac{e^{1/c}-1}{e^{1/c}+1}
\sim
\frac1{2c}.
$$

对于一般的 $\ell_s$ 空间，由于在 $\{0,1\}^d$ 上

$$
\|x-y\|_s
=
\|x-y\|_1^{1/s},
$$

所以 $\ell_s$ 中的距离放大因子 $c$，对应于 Hamming 距离中的放大因子 $c^s$。最终得到

$$
\rho_s(c)
\ge
\frac{e^{1/c^s}-1}{e^{1/c^s}+1}
\ge
\frac{0.462}{c^s}.
$$

整个证明可以概括为

$$
\boxed{
\text{远点碰撞限制哈希桶大小}
\Longrightarrow
\text{近点碰撞转化为随机游走留存}
\Longrightarrow
\text{小集合扩散限制留存概率}
\Longrightarrow
\text{得到 }\rho\text{ 的下界}
}
$$

这里更准确的表述不是“证明 LSH”，而是“证明 LSH 参数 $\rho$ 的下界”。

## Prompt:
需要解释其中的傅里叶分析

## Response:
我会把第三步中的傅里叶分析单独拆开，重点说明它为什么能把“随机游走留在集合内的概率”转化为集合大小的幂次上界。

> **解释傅里叶分析与相关定理**
>
>
> **解释傅里叶分析与随机游走特征并获取结果**
>
> 
>
> 思考了 17s

### 第三步：利用傅里叶分析证明小集合扩散性质

为了限制随机游走留在同一哈希桶中的概率，论文把哈希桶看作 Hamming 立方体中的集合

$$
B\subseteq\{0,1\}^d,
$$

并研究：从 $B$ 中均匀选择一个起点，进行 $r$ 步随机游走后，终点仍落在 $B$ 中的概率。

傅里叶分析的作用，是把复杂的随机游走过程分解成若干个彼此独立、行为简单的“频率分量”。

#### 1. Hamming 立方体上的傅里叶基

在普通的傅里叶分析中，一个函数可以分解为正弦和余弦函数的线性组合。在 Hamming 立方体 $\{0,1\}^d$ 上，对应的基本函数是 Walsh 函数。

对于任意坐标集合

$$
S\subseteq\{1,\ldots,d\},
$$

定义

$$
W_S(u)
=
(-1)^{\sum_{j\in S}u_j}.
$$

它只关心 $u$ 在集合 $S$ 中的坐标之和是奇数还是偶数。

例如，当 $d=3$、$S=\{1,3\}$ 时，

$$
W_S(u)=(-1)^{u_1+u_3}.
$$

如果 $u_1$ 和 $u_3$ 中有偶数个 $1$，函数值为 $1$；如果有奇数个 $1$，函数值为 $-1$。

所有 $2^d$ 个 Walsh 函数构成了 Hamming 立方体上函数空间的一组正交基。因此，任意函数

$$
f:\{0,1\}^d\to\mathbb R
$$

都可以唯一表示为

$$
f(u)
=
\sum_{S\subseteq[d]}
\widehat f(S)W_S(u),
$$

其中

$$
\widehat f(S)
=
\frac1{2^d}
\sum_{u\in\{0,1\}^d}
f(u)W_S(u)
$$

称为 $f$ 在频率 $S$ 上的傅里叶系数。

傅里叶系数描述了函数在不同坐标组合上的变化程度。通常，$|S|$ 较小的项称为低频分量，$|S|$ 较大的项称为高频分量。

---

#### 2. 用指示函数表示哈希桶

对于集合 $B$，定义它的指示函数

$$
\mathbf 1_B(u)
=
\begin{cases}
1,&u\in B,\\
0,&u\notin B.
\end{cases}
$$

于是，研究随机游走是否回到 $B$，就可以转化为研究函数 $\mathbf 1_B$。

在 Hamming 立方体上定义归一化内积

$$
\langle f,g\rangle
=
\frac1{2^d}
\sum_{u\in\{0,1\}^d}f(u)g(u).
$$

根据 Parseval 恒等式，

$$
\langle f,g\rangle
=
\sum_{S\subseteq[d]}
\widehat f(S)\widehat g(S).
$$

特别地，

$$
\sum_{S\subseteq[d]}
\widehat{\mathbf 1_B}(S)^2
=
\langle\mathbf 1_B,\mathbf 1_B\rangle
=
\frac{|B|}{2^d}.
$$

因此，集合 $B$ 的大小等于它的傅里叶能量总和。

令

$$
\beta=\frac{|B|}{2^d}
$$

表示集合 $B$ 在整个 Hamming 立方体中所占的比例，则

$$
\sum_S\widehat{\mathbf 1_B}(S)^2=\beta.
$$

---

#### 3. Walsh 函数是随机游走的特征函数

设 $P$ 是 Hamming 立方体上的一步随机游走算子。它的作用是：从当前点出发，均匀随机选择一个坐标并翻转。

对于函数 $f$，

$$
(Pf)(u)
=
\frac1d
\sum_{v:\|u-v\|_1=1}f(v).
$$

关键性质是，每个 Walsh 函数 $W_S$ 都是 $P$ 的特征函数：

$$
PW_S
=
\left(1-\frac{2|S|}{d}\right)W_S.
$$

原因如下。

一次随机游走会随机翻转一个坐标：

- 如果翻转的坐标不在 $S$ 中，$W_S$ 的值不变，共有 $d-|S|$ 种选择；
- 如果翻转的坐标在 $S$ 中，奇偶性发生变化，$W_S$ 的符号取反，共有 $|S|$ 种选择。

因此

$$
(PW_S)(u)
=
\frac{d-|S|}{d}W_S(u)
-
\frac{|S|}{d}W_S(u),
$$

即

$$
(PW_S)(u)
=
\left(1-\frac{2|S|}{d}\right)W_S(u).
$$

这一步是傅里叶分析能够简化随机游走的根本原因。

原本，随机游走算子 $P$ 对一般函数的作用很复杂；但在 Walsh 基下，$P$ 只需要把每个傅里叶系数乘以一个数。

经过 $r$ 步随机游走后，

$$
P^rW_S
=
\left(1-\frac{2|S|}{d}\right)^rW_S.
$$

所以，如果

$$
\mathbf 1_B
=
\sum_S
\widehat{\mathbf 1_B}(S)W_S,
$$

那么

$$
P^r\mathbf 1_B
=
\sum_S
\widehat{\mathbf 1_B}(S)
\left(1-\frac{2|S|}{d}\right)^r
W_S.
$$

---

#### 4. 将留在集合中的概率写成傅里叶和

从 $B$ 中均匀选择起点，经过 $r$ 步随机游走后仍然落在 $B$ 中的概率为

$$
\Pr[Q_B\in B]
=
\frac1{|B|}
\sum_{a\in B}\sum_{b\in B}(P^r)_{ab}.
$$

利用指示函数，可以写成

$$
\Pr[Q_B\in B]
=
\frac{2^d}{|B|}
\langle P^r\mathbf 1_B,\mathbf 1_B\rangle.
$$

再使用 Parseval 恒等式：

$$
\Pr[Q_B\in B]
=
\frac{2^d}{|B|}
\sum_{S\subseteq[d]}
\widehat{\mathbf 1_B}(S)^2
\left(1-\frac{2|S|}{d}\right)^r.
$$

由于

$$
\beta=\frac{|B|}{2^d},
$$

也可以写成

$$
\Pr[Q_B\in B]
=
\frac1\beta
\sum_{S\subseteq[d]}
\widehat{\mathbf 1_B}(S)^2
\left(1-\frac{2|S|}{d}\right)^r.
$$

这个公式说明，随机游走的留存概率由两部分决定：

1. 集合 $B$ 的傅里叶能量如何分布；
2. 不同频率在随机游走中以多快的速度衰减。

---

#### 5. 为什么要求 $r$ 是奇数

当

$$
|S|>\frac d2
$$

时，

$$
1-\frac{2|S|}{d}<0.
$$

如果 $r$ 是奇数，则

$$
\left(1-\frac{2|S|}{d}\right)^r<0.
$$

因此，这些高频项对总和的贡献是负数。为了得到概率的上界，可以直接将这些负项删除：

$$
\Pr[Q_B\in B]
\le
\frac1\beta
\sum_{|S|\le d/2}
\widehat{\mathbf 1_B}(S)^2
\left(1-\frac{2|S|}{d}\right)^r.
$$

这就是论文要求 $r$ 为奇数的原因。

如果 $r$ 是偶数，这些特征值的偶数次幂会变成正数，无法直接删除，高频分量可能增加上界，论文中的这一证明方法便不能原样使用。

对于 $|S|\le d/2$，使用基本不等式

$$
1-x\le e^{-x},
$$

得到

$$
\left(1-\frac{2|S|}{d}\right)^r
\le
e^{-2r|S|/d}.
$$

于是

$$
\Pr[Q_B\in B]
\le
\frac1\beta
\sum_S
\widehat{\mathbf 1_B}(S)^2
e^{-2r|S|/d}.
$$

---

#### 6. 使用 Bonami-Beckner 不等式

令

$$
\varepsilon=e^{-r/d}.
$$

那么

$$
e^{-2r|S|/d}
=
\varepsilon^{2|S|}.
$$

因此

$$
\Pr[Q_B\in B]
\le
\frac1\beta
\sum_S
\varepsilon^{2|S|}
\widehat{\mathbf 1_B}(S)^2.
$$

此时需要控制这个带有衰减因子的傅里叶能量和。论文使用 Bonami-Beckner 不等式：

$$
\sum_S
\varepsilon^{2|S|}
\widehat f(S)^2
\le
\|f\|_{1+\varepsilon^2}^2.
$$

这个不等式也称为超收缩不等式。它说明，对高频傅里叶系数乘上 $\varepsilon^{|S|}$ 后，函数的 $L_2$ 大小可以由原函数一个较低阶的 $L_p$ 范数控制。

取

$$
f=\mathbf 1_B,
$$

由于指示函数只能取 $0$ 和 $1$，对任意 $p>0$ 都有

$$
\mathbf 1_B(u)^p=\mathbf 1_B(u).
$$

因此

$$
\|\mathbf 1_B\|_{1+\varepsilon^2}
=
\left(
\frac1{2^d}\sum_u
\mathbf 1_B(u)
\right)^{1/(1+\varepsilon^2)}
=
\beta^{1/(1+\varepsilon^2)}.
$$

所以

$$
\sum_S
\varepsilon^{2|S|}
\widehat{\mathbf 1_B}(S)^2
\le
\beta^{2/(1+\varepsilon^2)}.
$$

代回随机游走概率：

$$
\Pr[Q_B\in B]
\le
\frac1\beta
\beta^{2/(1+\varepsilon^2)}.
$$

整理指数可得

$$
\Pr[Q_B\in B]
\le
\beta^{
\frac{1-\varepsilon^2}
{1+\varepsilon^2}
}.
$$

由于

$$
\varepsilon^2=e^{-2r/d},
$$

最终得到

$$
\Pr[Q_B\in B]
\le
\left(\frac{|B|}{2^d}\right)^{
\frac{1-e^{-2r/d}}
{1+e^{-2r/d}}
}.
$$

将分子分母同时乘以 $e^{2r/d}$，可写为

$$
\boxed{
\Pr[Q_B\in B]
\le
\left(\frac{|B|}{2^d}\right)^{
\frac{e^{2r/d}-1}
{e^{2r/d}+1}
}
}.
$$

这正是论文中的随机游走引理。`Lower Bounds on Locality Sensitive Hashing.pdf`

### 傅里叶分析在证明中的实际作用

傅里叶分析完成了以下转换：

$$
\text{随机游走留在集合中的概率}
$$

先被写成

$$
\text{随机游走算子作用于集合指示函数的内积},
$$

再被分解成

$$
\sum_S
\text{集合在频率 }S\text{ 上的能量}
\times
\text{该频率经过随机游走后的衰减率}.
$$

即

$$
\Pr[Q_B\in B]
=
\frac1\beta
\sum_S
\widehat{\mathbf 1_B}(S)^2
\left(1-\frac{2|S|}{d}\right)^r.
$$

Bonami-Beckner 不等式进一步把这个依赖集合具体形状的傅里叶和，仅用集合大小

$$
\beta=\frac{|B|}{2^d}
$$

控制住。

因此，无论哈希桶 $B$ 的形状多么复杂，只要它足够小，就必然满足

$$
\Pr[Q_B\in B]\le \beta^\alpha.
$$

这就是“小集合扩散”：小集合无法长期困住 Hamming 立方体上的随机游走。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)